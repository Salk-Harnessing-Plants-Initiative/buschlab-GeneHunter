#!/usr/bin/env python

# -*- coding: utf-8 -*-

"""genehunter.__main__: executed when genehunter directory is called as script."""

import sys
from genehunter.ghunter import main

if __name__ == '__main__':
    sys.exit(main())
