# -*- coding: utf-8 -*-

"""tairdbsuite.tairdb_models: module defining the classes which are mapped to the database by sqlalchemy."""

from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql.sqltypes import UnicodeText

Base=declarative_base()

class Tair_Gene(Base):
    __tablename__='tair10genes'
    id = Column(Integer, primary_key=True)
    db = Column(String)
    chromosome = Column(String(1))
    type = Column(String)
    loc_start = Column(Integer)
    loc_end = Column(Integer)
    orientation = Column(String(1))
    agi = Column(String)
    shortsym=Column(String)
    longsym=Column(String)
    attributes=Column(String)
    children = relationship("Tair_Level1", back_populates="parent")

class Tair_Level1(Base):
    __tablename__='tair10level1'
 
    id = Column(Integer,primary_key=True)
    model = Column(Integer)
    type = Column(String)
    loc_start = Column(Integer)
    loc_end = Column(Integer)
    attributes=Column(String)
    parent_id = Column(Integer, ForeignKey('tair10genes.id'))
    parent = relationship("Tair_Gene", back_populates="children")
    children = relationship("Tair_Level2")
    description = relationship("Tair_Desc", uselist=False, back_populates="level1")
    
class Tair_Level2(Base):
    __tablename__='tair10level2'
  
    id = Column(Integer,primary_key=True)
    type = Column(String)
    loc_start = Column(Integer)
    loc_end = Column(Integer)
    attributes=Column(String)
    level1_id = Column(Integer, ForeignKey('tair10level1.id'))
    level1 = relationship("Tair_Level1", back_populates="children")
    
class Tair_Desc(Base):
    __tablename__='tair10desc'
     
    id = Column(Integer,primary_key=True)
    shortdesc = Column(UnicodeText)
    curatorsummary = Column(UnicodeText)
    longdesc = Column(UnicodeText)
    type = Column(String)
    model = Column(Integer)
    level1_id = Column(Integer, ForeignKey('tair10level1.id'))
    level1 = relationship("Tair_Level1", back_populates="description")
